AORTA : Arpasing Oto Reorderer Tool Application
Made by NobodyP & Psychic_Digit using Python 3.11.3

++ Console-based ++

The version you are using was completed on June 29, 2023

Thank you for downloading this program, if you have any questions or
have encountered any bugs, put it in the Issues tab on the Github
page.

#####################################################################


----- What this program does

This program was made to sort the contents of an oto.ini file into
multiple different text files based on the phonemes within each line.


----- How to run and use the program

1. Make sure you have your oto.ini file in the same directory as this
   program, as well an output folder named "oto_split"

2. Run the .exe file

3. Press enter and wait for the program to finish

4. When the program has finished, press enter to exit the program

5. Close the window

6. Check the output folder, and the sorted contents of the oto.ini
   file should be there

7. You are done


#####################################################################