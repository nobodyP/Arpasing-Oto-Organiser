This is the unfinished readme file for
AORTA : Arpasing OTO Reordering Tool Application
(name may not be final)

By NobodyP & Psychic_Digit in Python 3.11.3
6/17/23


Basically this program takes an oto.ini file, searches through the contents, and sorts every entry into a text file based on which phoneme or phoneme combo it has.

Some things to know:

- The code of this program is kinda sloppy, and we have not tested it a whole lot, so there   may be some errors

- This program runs in the console

- This program requires a folder named "oto_split" to be in the same directory as itself to function, so you should create a folder and name it "oto_split" if that folder is not already present

- An oto.ini file is also required to be in the same directory as the program

- This program creates text files within the "oto_split" folder to sort the different entries of oto.ini into. It also creates a text file called "no_phonemes_found.txt" for entries in which a phoneme or phoneme combo could not be found, which may be due to a bug   in the program