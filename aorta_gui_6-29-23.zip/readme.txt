AORTA : Arpasing Oto Reorderer Tool Application
Made by NobodyP & Psychic_Digit using Python 3.11.3

++ Window-based ++

The version you are using was completed on June 29, 2023

Thank you for downloading this program, if you have any questions or
have encountered any bugs, put it in the Issues tab on the Github
page.

#####################################################################


----- What this program does

This program was made to sort the contents of an oto.ini file into
multiple different text files based on the phonemes within each line.


----- How to run and use the program

1. Run the .exe file

2. Specify the path of the oto.ini file and output folder

3. Click the "Start Program" button

4. Wait for the status bar to say "Program complete, you may now
   close the window"

5. Click the "Exit" button

6. Check the output folder you selected previously, and the sorted
   contents of the oto.ini file should be there

7. You are done


#####################################################################